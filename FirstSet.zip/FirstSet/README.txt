Nodetest1 is my personal javascript site that I have been using to play around with basic concepts (and test some possible ways to make use of database calls/promises). It doesnt really have any bearing on my tasks but I included it anyway since its been part of my learning

authenticationIntro-master is the main javascript project. It more than accomplishes the task given, though is not made form scratch. I closely followed the associated tutorial and the last step was to download what bits he did not guide you in making yourself. I have spent most of my time in javascript trying to understand what is in this file

The shell command I ended up with is also provided. Obviously you can change what server you want to point it at pretty easily.  